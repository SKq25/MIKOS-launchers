package com.mikos.launcher

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.os.Build
import android.provider.AlarmClock
import android.provider.MediaStore
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable fun VSlider(v: Float, e: String, onV: (Float) -> Unit) {
    var h by remember { mutableFloatStateOf(1f) }
    Box(
        Modifier.width(72.dp).height(170.dp).glass(30.dp).onSizeChanged { h = it.height.toFloat() }
            .pointerInput(Unit) { detectVerticalDragGestures { ch, _ -> onV((1f - ch.position.y / h).coerceIn(0f, 1f)) } }
            .pointerInput(Unit) { detectTapGestures { onV((1f - it.y / h).coerceIn(0f, 1f)) } },
        contentAlignment = Alignment.BottomCenter
    ) {
        Box(Modifier.fillMaxWidth().fillMaxHeight(v.coerceIn(0.02f, 1f)).background(Color(0xDDFFFFFF)))
        Text(e, fontSize = 22.sp, modifier = Modifier.align(Alignment.TopCenter).padding(top = 12.dp))
    }
}

@Composable fun SquareTile(e: String, n: String, on: Boolean, mod: Modifier, f: () -> Unit) {
    Column(
        mod.aspectRatio(1f).glass(24.dp).background(if (on) Brush.linearGradient(listOf(Color(0xAA6A3CFF), Color(0xAA4DC3FF))) else Brush.linearGradient(listOf(Color.Transparent, Color.Transparent))).clickable { f() },
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
    ) { Text(e, fontSize = 24.sp); Text(n, color = Color.White, fontSize = 11.sp) }
}

@Composable fun ControlCenter(go: (String?) -> Unit) {
    val ctx = LocalContext.current; val bat = battery(); val w = Store.weather
    val am = remember { ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    val mx = remember { am.getStreamMaxVolume(AudioManager.STREAM_MUSIC) }
    var vol by remember { mutableFloatStateOf(am.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / mx) }
    var br by remember { mutableFloatStateOf(.8f) }
    Column(
        Modifier.fillMaxSize().background(Color(0xE60A0C24))
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {}
            .statusBarsPadding().padding(top = 50.dp, start = 16.dp, end = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Column(Modifier.weight(1f).height(170.dp).glass(30.dp).padding(14.dp), verticalArrangement = Arrangement.SpaceEvenly) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    RoundBtn("✈️") { ctx.go(Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS)) }
                    RoundBtn("📡") { ctx.go(Intent(Settings.ACTION_WIRELESS_SETTINGS)) }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    RoundBtn("📶") { ctx.go(Intent(if (Build.VERSION.SDK_INT >= 29) Settings.Panel.ACTION_INTERNET_CONNECTIVITY else Settings.ACTION_WIFI_SETTINGS)) }
                    RoundBtn("ᛒ") { ctx.go(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) }
                }
            }
            VSlider(br, "☀️") { br = it; (ctx as? Activity)?.window?.let { win -> val a = win.attributes; a.screenBrightness = it.coerceAtLeast(.1f); win.attributes = a } }
            VSlider(vol, "🔊") { vol = it; am.setStreamVolume(AudioManager.STREAM_MUSIC, (it * mx).toInt(), 0) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            SquareTile("🔦", "Torch", TorchCtl.on, Modifier.weight(1f)) { TorchCtl.toggle(ctx) }
            SquareTile("🌙", "Focus", false, Modifier.weight(1f)) { ctx.go(Intent(Settings.ACTION_ZEN_MODE_PRIORITY_SETTINGS)) }
            SquareTile("⏱️", "Timer", false, Modifier.weight(1f)) { ctx.go(Intent(AlarmClock.ACTION_SHOW_ALARMS)) }
            SquareTile("📷", "Camera", false, Modifier.weight(1f)) { ctx.go(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            SquareTile("🔢", "Calc", false, Modifier.weight(1f)) { go("Calculator") }
            SquareTile("📝", "Notes", false, Modifier.weight(1f)) { go("Notes") }
            SquareTile("🧭", "Speed", false, Modifier.weight(1f)) { go("Speed") }
            SquareTile("🤖", "AI", false, Modifier.weight(1f)) { go("AI") }
        }
        Column(Modifier.fillMaxWidth().glass().padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("Live Activities", color = Color.White, fontWeight = FontWeight.Bold)
            Text("⚡ Battery $bat%", color = Color.White)
            Text("${w?.let { wxIcon(it.code) } ?: "⛅"} $CITY ${w?.temp ?: "--"}° · ${w?.let { wxText(it.code) } ?: "…"}", color = Color.White)
        }
        Text("✕ Band karo", color = Color(0xCCFFFFFF), modifier = Modifier.align(Alignment.CenterHorizontally).clickable { go(null) }.padding(10.dp))
    }
}

@Composable fun Drawer(apps: List<App>, open: (String?) -> Unit) {
    var q by remember { mutableStateOf("") }
    val list = remember(q, apps) { apps.filter { it.label.contains(q, true) } }
    val mine = listOf("🤖" to "AI", "🧭" to "Speed", "⛅" to "Weather", "📝" to "Notes", "🔢" to "Calculator")
    Column(Modifier.fillMaxSize().background(Color(0xF2070920)).statusBarsPadding().navigationBarsPadding().padding(top = 50.dp, start = 14.dp, end = 14.dp)) {
        OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth(), placeholder = { Text("App Library search…") }, singleLine = true, shape = RoundedCornerShape(26.dp))
        Spacer(Modifier.height(12.dp))
        if (q.isEmpty()) {
            Text("MIKOS Apps", color = Color.White, fontWeight = FontWeight.SemiBold)
            Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                mine.forEach { (e, n) ->
                    Column(Modifier.width(62.dp).clickable { open(n) }, horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(Modifier.size(54.dp).clip(RoundedCornerShape(14.dp)).background(Brush.linearGradient(listOf(Color(0xFF6A3CFF), Color(0xFF2F9BFF)))), contentAlignment = Alignment.Center) { Text(e, fontSize = 26.sp) }
                        Text(n, color = Color.White, fontSize = 11.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 4.dp))
                    }
                }
            }
        }
        LazyVerticalGrid(GridCells.Fixed(4), verticalArrangement = Arrangement.spacedBy(14.dp)) { items(list, key = { it.pkg }) { AppIcon(it) } }
    }
}
