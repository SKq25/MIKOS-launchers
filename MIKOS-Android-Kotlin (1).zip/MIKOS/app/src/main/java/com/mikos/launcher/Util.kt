package com.mikos.launcher

import android.content.*
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.os.BatteryManager
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import androidx.compose.foundation.shape.RoundedCornerShape
import org.json.JSONObject
import java.math.BigDecimal
import java.math.RoundingMode
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

// ---- Apna sheher yaha badlo ----
const val CITY = "Dehradun"
const val LAT = 30.3165
const val LON = 78.0322

data class App(val label: String, val pkg: String, val icon: ImageBitmap)

fun loadApps(c: Context): List<App> {
    val pm = c.packageManager
    val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(i, 0)
        .filter { it.activityInfo.packageName != c.packageName }
        .map { App(it.loadLabel(pm).toString(), it.activityInfo.packageName, it.loadIcon(pm).toBitmap(128, 128).asImageBitmap()) }
        .distinctBy { it.pkg }
        .sortedBy { it.label.lowercase() }
}

fun Context.go(i: Intent) {
    try { startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    catch (e: Exception) { Toast.makeText(this, "Ye feature is device par nahi mila", Toast.LENGTH_SHORT).show() }
}

fun Context.launchPkg(pkg: String) {
    val i = packageManager.getLaunchIntentForPackage(pkg)
    if (i != null) go(i) else Toast.makeText(this, "App nahi mila", Toast.LENGTH_SHORT).show()
}

fun Modifier.glass(r: Dp = 22.dp): Modifier {
    val s = RoundedCornerShape(r)
    return this
        .shadow(10.dp, s, clip = false, ambientColor = Color(0x664A7BFF), spotColor = Color(0x664A7BFF))
        .clip(s)
        .background(Brush.linearGradient(listOf(Color(0xB3162262), Color(0x990A0A2A))))
        .border(1.dp, Brush.verticalGradient(listOf(Color(0x99FFFFFF), Color(0x336EA0FF))), s)
}

object TorchCtl {
    var on by mutableStateOf(false)
    fun toggle(c: Context) {
        on = !on
        try {
            val cm = c.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
            if (id != null) cm.setTorchMode(id, on)
        } catch (_: Exception) {}
    }
}

@Composable fun now(): Date {
    var d by remember { mutableStateOf(Date()) }
    LaunchedEffect(Unit) { while (true) { d = Date(); delay(1000) } }
    return d
}

@Composable fun battery(): Int {
    val c = LocalContext.current
    var b by remember { mutableIntStateOf(100) }
    DisposableEffect(Unit) {
        val r = object : BroadcastReceiver() {
            override fun onReceive(x: Context, i: Intent) {
                b = i.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) * 100 / i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
            }
        }
        c.registerReceiver(r, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        onDispose { c.unregisterReceiver(r) }
    }
    return b
}

// ---------------- Weather (Open-Meteo, free, no API key) ----------------
data class Day(val name: String, val hi: Int, val lo: Int, val code: Int)
data class Weather(val temp: Int, val code: Int, val days: List<Day>)
object Store { var weather by mutableStateOf<Weather?>(null) }

fun wxIcon(c: Int) = when (c) { 0 -> "☀️"; 1, 2 -> "⛅"; 3 -> "☁️"; 45, 48 -> "🌫️"; in 51..67 -> "🌧️"; in 71..77 -> "❄️"; in 80..82 -> "🌦️"; in 95..99 -> "⛈️"; else -> "🌤️" }
fun wxText(c: Int) = when (c) { 0 -> "Clear"; 1, 2 -> "Partly Cloudy"; 3 -> "Cloudy"; 45, 48 -> "Fog"; in 51..67 -> "Rain"; in 71..77 -> "Snow"; in 80..82 -> "Showers"; in 95..99 -> "Thunderstorm"; else -> "Fair" }

suspend fun fetchWeather() = withContext(Dispatchers.IO) {
    try {
        val u = "https://api.open-meteo.com/v1/forecast?latitude=$LAT&longitude=$LON&current=temperature_2m,weather_code&daily=temperature_2m_max,temperature_2m_min,weather_code&timezone=auto&forecast_days=4"
        val c = URL(u).openConnection() as HttpURLConnection
        c.connectTimeout = 6000; c.readTimeout = 6000
        val j = JSONObject(c.inputStream.bufferedReader().readText())
        val cur = j.getJSONObject("current"); val d = j.getJSONObject("daily")
        val hi = d.getJSONArray("temperature_2m_max"); val lo = d.getJSONArray("temperature_2m_min")
        val cd = d.getJSONArray("weather_code"); val dt = d.getJSONArray("time")
        val days = (0 until hi.length()).map {
            val dd = SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(dt.getString(it))!!
            Day(SimpleDateFormat("EEE", Locale.US).format(dd), hi.getDouble(it).roundToInt(), lo.getDouble(it).roundToInt(), cd.getInt(it))
        }
        Store.weather = Weather(cur.getDouble("temperature_2m").roundToInt(), cur.getInt("weather_code"), days)
    } catch (_: Exception) {}
}

// ---------------- Calculator engine ----------------
class Ev(val s: String) {
    var i = 0
    fun p(): Double { var v = t(); while (i < s.length && (s[i] == '+' || s[i] == '-')) { val o = s[i++]; val r = t(); v = if (o == '+') v + r else v - r }; return v }
    fun t(): Double { var v = f(); while (i < s.length && (s[i] == '*' || s[i] == '/')) { val o = s[i++]; val r = f(); v = if (o == '*') v * r else v / r }; return v }
    fun f(): Double {
        if (i < s.length && s[i] == '-') { i++; return -f() }
        if (i < s.length && s[i] == '(') { i++; val v = p(); i++; return v }
        val st = i
        while (i < s.length && (s[i].isDigit() || s[i] == '.')) i++
        return s.substring(st, i).toDouble()
    }
}

fun calc(s: String): String? = try {
    val q = s.replace('×', '*').replace('÷', '/').replace('−', '-').replace("%", "/100")
    val e = Ev(q); val v = e.p()
    if (e.i < q.length || v.isNaN() || v.isInfinite()) null
    else BigDecimal(v).setScale(8, RoundingMode.HALF_UP).stripTrailingZeros().toPlainString()
} catch (_: Exception) { null }

fun aiReply(t0: String): String {
    val t = t0.lowercase(Locale.getDefault()); val w = Store.weather
    return when {
        Regex("plan|schedule|study").containsMatchIn(t) -> "📚 Study plan: 7–9 Maths, 10–12 Physics, 4–5 Revision, 8 PM Chemistry practice."
        Regex("time|samay").containsMatchIn(t) -> "Abhi samay " + SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())
        Regex("weather|mausam").containsMatchIn(t) -> if (w != null) "${wxIcon(w.code)} $CITY: ${w.temp}°C, ${wxText(w.code)}" else "Weather abhi load nahi hua, internet check karo."
        Regex("write|message").containsMatchIn(t) -> "✍️ Draft: \"Hi! Kal milte hain, time confirm kar dena. Thanks!\""
        Regex("summar").containsMatchIn(t) -> "📝 Text paste karo, main 3 points me bata dunga."
        Regex("image").containsMatchIn(t) -> "🎨 Image feature abhi demo hai."
        Regex("hello|namaste|^hi").containsMatchIn(t) -> "Namaste! 😊"
        else -> "Samajh gaya: \"${t0.take(40)}\". (Local demo AI, rule-based)"
    }
}
