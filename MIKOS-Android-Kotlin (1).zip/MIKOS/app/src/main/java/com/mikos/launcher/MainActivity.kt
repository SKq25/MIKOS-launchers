package com.mikos.launcher

import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.content.Intent
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { MikosRoot() } }
    }
}

@Composable fun MikosRoot() {
    val ctx = LocalContext.current
    val hap = LocalHapticFeedback.current
    val apps = remember { loadApps(ctx) }
    var drawer by remember { mutableStateOf(false) }
    var cc by remember { mutableStateOf(false) }
    var locked by remember { mutableStateOf(true) }
    var app by remember { mutableStateOf<String?>(null) }
    var last by remember { mutableStateOf("AI") }
    if (app != null) last = app!!
    LaunchedEffect(Unit) { fetchWeather() }
    BackHandler(app != null || drawer || cc) { if (app != null) app = null else { drawer = false; cc = false } }
    Box(
        Modifier.fillMaxSize().background(Color.Black).pointerInput(Unit) {
            var t = 0f
            detectVerticalDragGestures(
                onDragStart = { t = 0f },
                onDragEnd = {
                    if (app == null) {
                        if (locked) { if (t < -140) { locked = false; hap.performHapticFeedback(HapticFeedbackType.LongPress) } }
                        else if (drawer) { if (t > 160) drawer = false }
                        else if (cc) { if (t < -160) cc = false }
                        else { if (t < -160) drawer = true else if (t > 160) cc = true }
                    }
                },
                onVerticalDrag = { _, d -> t += d }
            )
        }
    ) {
        Wallpaper()
        Home(apps, { app = it }, { cc = true }, { drawer = true })
        AnimatedVisibility(drawer, enter = slideInVertically { it } + fadeIn(), exit = slideOutVertically { it } + fadeOut()) {
            Drawer(apps) { drawer = false; app = it }
        }
        AnimatedVisibility(cc, enter = slideInVertically { -it }, exit = slideOutVertically { -it }) {
            ControlCenter { cc = false; if (it != null) app = it }
        }
        AnimatedVisibility(app != null, enter = scaleIn(initialScale = .3f) + fadeIn(), exit = scaleOut(targetScale = .3f) + fadeOut()) {
            AppHost(last) { app = null }
        }
        StatusLayer()
        AnimatedVisibility(locked, exit = slideOutVertically { -it } + fadeOut()) { Lock() }
    }
}

@Composable fun StatusLayer() {
    val d = now(); val bat = battery(); val w = Store.weather
    var open by remember { mutableStateOf(false) }
    LaunchedEffect(open) { if (open) { delay(3500); open = false } }
    val iw by animateDpAsState(if (open) 300.dp else 112.dp, spring(dampingRatio = .6f))
    val ih by animateDpAsState(if (open) 78.dp else 32.dp, spring(dampingRatio = .6f))
    val time = SimpleDateFormat("H:mm", Locale.getDefault()).format(d)
    Box(Modifier.fillMaxWidth().statusBarsPadding().padding(top = 6.dp)) {
        Text(time, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, modifier = Modifier.align(Alignment.TopStart).padding(start = 28.dp, top = 6.dp))
        Text("5G  ▮ $bat%", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Medium, modifier = Modifier.align(Alignment.TopEnd).padding(end = 24.dp, top = 8.dp))
        Box(Modifier.align(Alignment.TopCenter).size(iw, ih).clip(RoundedCornerShape(ih / 2)).background(Color.Black).clickable { open = !open }, contentAlignment = Alignment.Center) {
            if (open) Text("🔋 $bat%   ·   ${w?.let { "${wxIcon(it.code)} ${it.temp}°" } ?: "⛅ --"}   ·   $time", color = Color.White, fontSize = 14.sp)
        }
    }
}

@Composable fun Lock() {
    val ctx = LocalContext.current; val d = now()
    Box(Modifier.fillMaxSize().background(Color(0x99000000))) {
        Column(Modifier.fillMaxSize().statusBarsPadding().padding(top = 90.dp, start = 18.dp, end = 18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(SimpleDateFormat("EEE, d MMM", Locale.getDefault()).format(d), color = Color.White, fontSize = 17.sp)
            Text(SimpleDateFormat("H:mm", Locale.getDefault()).format(d), style = TextStyle(fontSize = 92.sp, fontWeight = FontWeight.ExtraLight, color = Color.White, shadow = Shadow(Color(0xFF8AB0FF), Offset.Zero, 30f)))
            Spacer(Modifier.height(24.dp))
            Column(Modifier.fillMaxWidth().glass().padding(14.dp)) { Text("💬 WhatsApp · abhi", color = Color.White, fontSize = 12.sp); Text("Rahul: Bhai MIKOS ekdum real lag raha hai 🔥", color = Color.White) }
            Spacer(Modifier.height(10.dp))
            Column(Modifier.fillMaxWidth().glass().padding(14.dp)) { Text("🌐 5G · Connected", color = Color.White, fontSize = 12.sp); Text("Speed test chalane ke liye unlock karo", color = Color.White) }
            Spacer(Modifier.weight(1f))
            Row(Modifier.fillMaxWidth().navigationBarsPadding().padding(bottom = 30.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                RoundBtn("🔦", TorchCtl.on) { TorchCtl.toggle(ctx) }
                Text("⌃ Upar swipe karo", color = Color(0xCCFFFFFF), fontSize = 13.sp, modifier = Modifier.align(Alignment.CenterVertically))
                RoundBtn("📷", false) { ctx.go(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)) }
            }
        }
    }
}

@Composable fun RoundBtn(e: String, on: Boolean = false, f: () -> Unit) {
    Box(
        Modifier.size(52.dp).clip(CircleShape).background(if (on) Brush.linearGradient(listOf(Color(0xFF6A3CFF), Color(0xFF4DC3FF))) else Brush.linearGradient(listOf(Color(0x44FFFFFF), Color(0x33FFFFFF))))
            .clickable { f() }, contentAlignment = Alignment.Center
    ) { Text(e, fontSize = 22.sp) }
}

@Composable fun Home(apps: List<App>, open: (String) -> Unit, openCC: () -> Unit, openDrawer: () -> Unit) {
    val ctx = LocalContext.current
    val pager = rememberPagerState { 2 }
    val fav = remember(apps) {
        val want = listOf("com.google.android.youtube", "com.discord", "com.whatsapp", "com.instagram.android", "com.android.vending", "com.android.chrome", "com.spotify.music", "com.netflix.mediaclient")
        val f = want.mapNotNull { p -> apps.find { it.pkg == p } }
        (f + apps.filter { it !in f }).take(8)
    }
    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(top = 44.dp, start = 14.dp, end = 14.dp, bottom = 8.dp)) {
        HorizontalPager(pager, Modifier.weight(1f)) { p -> if (p == 0) PageOne(fav, open) else PageTwo(open) }
        Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.Center) {
            repeat(2) { Box(Modifier.padding(3.dp).size(7.dp).clip(CircleShape).background(Color.White.copy(alpha = if (pager.currentPage == it) 1f else .35f))) }
        }
        Row(Modifier.align(Alignment.CenterHorizontally).glass(20.dp).clickable { openDrawer() }.padding(horizontal = 22.dp, vertical = 8.dp)) {
            Text("🔍 Search", color = Color(0xDDFFFFFF), fontSize = 13.sp)
        }
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth().glass(34.dp).padding(8.dp), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
            DockBtn("📞") { ctx.go(Intent(Intent.ACTION_DIAL)) }
            DockBtn("💬") { ctx.go(Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MESSAGING)) }
            Box(Modifier.size(58.dp).clip(CircleShape).background(Brush.radialGradient(listOf(Color.White, Color(0xFF4DC3FF), Color(0xFF6A3CFF)))).clickable { open("AI") })
            DockBtn("🧭") { open("Speed") }
            DockBtn("📷") { ctx.go(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)) }
        }
    }
}

@Composable fun PageOne(fav: List<App>, open: (String) -> Unit) {
    val d = now(); val w = Store.weather
    val hr = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
    val greet = when { hr < 12 -> "Good Morning"; hr < 17 -> "Good Afternoon"; else -> "Good Evening" }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Column {
                Text(SimpleDateFormat("H:mm", Locale.getDefault()).format(d), style = TextStyle(fontSize = 70.sp, fontWeight = FontWeight.ExtraLight, color = Color.White, shadow = Shadow(Color(0xFF8AB0FF), Offset.Zero, 28f)))
                Text(SimpleDateFormat("EEE, d MMM yyyy", Locale.getDefault()).format(d), color = Color.White)
            }
            Column(Modifier.clickable { open("Weather") }, horizontalAlignment = Alignment.End) {
                Text("${w?.let { wxIcon(it.code) } ?: "⛅"} ${w?.temp ?: "--"}°", fontSize = 30.sp, color = Color.White)
                Text(w?.let { wxText(it.code) } ?: "Loading…", fontSize = 12.sp, color = Color.White)
                Text(CITY, fontSize = 12.sp, color = Color(0xCCFFFFFF))
            }
        }
        Spacer(Modifier.height(14.dp))
        Row(Modifier.fillMaxWidth().glass(30.dp).clickable { open("AI") }.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(34.dp).clip(CircleShape).background(Brush.radialGradient(listOf(Color.White, Color(0xFF4DC3FF), Color(0xFF6A3CFF)))))
            Spacer(Modifier.width(12.dp))
            Column { Text("$greet, Vinod", color = Color.White, fontWeight = FontWeight.Bold); Text("Your day is looking great!", color = Color(0xCCFFFFFF), fontSize = 12.sp) }
        }
        Spacer(Modifier.weight(1f))
        Column(Modifier.fillMaxWidth().glass().padding(vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            fav.chunked(4).forEach { row ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    row.forEach { AppIcon(it) }
                    repeat(4 - row.size) { Spacer(Modifier.width(72.dp)) }
                }
            }
        }
    }
}

@Composable fun PageTwo(open: (String) -> Unit) {
    val w = Store.weather; val bat = battery()
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Column(Modifier.fillMaxWidth().glass().clickable { open("Weather") }.padding(16.dp)) {
            Text("Weather · $CITY", color = Color(0xCCFFFFFF), fontSize = 12.sp)
            Text("${w?.temp ?: "--"}°  ${w?.let { wxText(it.code) } ?: ""}", color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Light)
            Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                (w?.days ?: emptyList()).forEach { Column(horizontalAlignment = Alignment.CenterHorizontally) { Text(it.name, color = Color.White, fontSize = 12.sp); Text(wxIcon(it.code), fontSize = 22.sp); Text("${it.hi}°/${it.lo}°", color = Color.White, fontSize = 11.sp) } }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Column(Modifier.weight(1f).glass().padding(16.dp)) { Text("🔋 Battery", color = Color(0xCCFFFFFF), fontSize = 12.sp); Text("$bat%", color = Color.White, fontSize = 30.sp) }
            Column(Modifier.weight(1f).glass().clickable { open("Speed") }.padding(16.dp)) { Text("⚡ 5G Speed", color = Color(0xCCFFFFFF), fontSize = 12.sp); Text("Test chalao", color = Color.White, fontSize = 20.sp) }
        }
        Column(Modifier.fillMaxWidth().glass().clickable { open("AI") }.padding(16.dp)) {
            Text("🤖 AI Assistant", color = Color.White, fontWeight = FontWeight.Bold)
            Text("\"Plan my study schedule for this week\"", color = Color(0xCCFFFFFF), fontSize = 13.sp)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Column(Modifier.weight(1f).glass().clickable { open("Notes") }.padding(16.dp)) { Text("📝 Notes", color = Color.White, fontWeight = FontWeight.Bold); Text("Likho aur save karo", color = Color(0xCCFFFFFF), fontSize = 12.sp) }
            Column(Modifier.weight(1f).glass().clickable { open("Calculator") }.padding(16.dp)) { Text("🔢 Calculator", color = Color.White, fontWeight = FontWeight.Bold); Text("Quick math", color = Color(0xCCFFFFFF), fontSize = 12.sp) }
        }
    }
}

@Composable fun DockBtn(e: String, f: () -> Unit) {
    Box(Modifier.size(46.dp).clip(CircleShape).background(Color(0x33FFFFFF)).clickable { f() }, contentAlignment = Alignment.Center) { Text(e, fontSize = 22.sp) }
}

@Composable fun AppIcon(a: App) {
    val ctx = LocalContext.current
    Column(Modifier.width(72.dp).clickable { ctx.launchPkg(a.pkg) }, horizontalAlignment = Alignment.CenterHorizontally) {
        Image(a.icon, a.label, Modifier.size(54.dp).clip(RoundedCornerShape(14.dp)))
        Text(a.label, color = Color.White, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 4.dp))
    }
}
