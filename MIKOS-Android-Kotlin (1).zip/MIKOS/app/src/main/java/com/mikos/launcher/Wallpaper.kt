package com.mikos.launcher

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path

@Composable fun Wallpaper() {
    Canvas(Modifier.fillMaxSize()) {
        val w = size.width; val h = size.height
        fun poly(vararg p: Pair<Float, Float>) = Path().apply {
            moveTo(p[0].first * w, p[0].second * h)
            for (k in 1 until p.size) lineTo(p[k].first * w, p[k].second * h)
            close()
        }
        drawRect(Brush.verticalGradient(listOf(Color(0xFF140F45), Color(0xFF5B3A9E), Color(0xFFFF7F6A), Color(0xFFFFC27A))))
        val sun = Offset(w * .72f, h * .56f)
        drawCircle(Brush.radialGradient(listOf(Color(0xFFFFF5CF), Color.Transparent), sun, w * .38f), w * .38f, sun)
        listOf(.1f to .30f, .33f to .36f, .85f to .28f, .58f to .33f, .92f to .40f, .2f to .2f, .7f to .15f).forEach {
            drawCircle(Color.White.copy(alpha = .85f), 2.5f, Offset(w * it.first, h * it.second))
        }
        drawPath(poly(0f to .66f, .14f to .58f, .28f to .64f, .42f to .55f, .56f to .65f, .72f to .56f, .88f to .63f, 1f to .59f, 1f to 1f, 0f to 1f), Color(0xCC3A2A78))
        drawPath(poly(0f to .74f, .2f to .67f, .36f to .72f, .56f to .66f, .78f to .73f, 1f to .68f, 1f to 1f, 0f to 1f), Color(0xFF241A55))
        // floating island
        val body = Path().apply {
            moveTo(w * .28f, h * .56f); quadraticBezierTo(w * .5f, h * .53f, w * .72f, h * .56f)
            lineTo(w * .63f, h * .67f); quadraticBezierTo(w * .5f, h * .76f, w * .37f, h * .67f); close()
        }
        drawPath(body, Color(0xFF2A1F55))
        drawOval(Color(0xFF4B7A5A), Offset(w * .25f, h * .545f), Size(w * .5f, h * .03f))
        drawRect(Color(0xFFA99BE6), Offset(w * .44f, h * .49f), Size(w * .03f, h * .06f))
        drawRect(Color(0xFFA99BE6), Offset(w * .5f, h * .47f), Size(w * .035f, h * .08f))
        drawRect(Color(0xFFA99BE6), Offset(w * .56f, h * .50f), Size(w * .027f, h * .05f))
        drawPath(poly(.43f to .49f, .455f to .465f, .48f to .49f), Color(0xFFD3B2FF))
        drawPath(poly(.495f to .47f, .5175f to .44f, .54f to .47f), Color(0xFFD3B2FF))
        drawPath(poly(.555f to .50f, .5735f to .475f, .59f to .50f), Color(0xFFD3B2FF))
        drawRect(Color(0xAA9FD8FF), Offset(w * .485f, h * .70f), Size(w * .01f, h * .13f))
        // character
        drawCircle(Color(0xFF0D0D28), w * .022f, Offset(w * .5f, h * .805f))
        drawPath(poly(.465f to .93f, .475f to .83f, .525f to .83f, .535f to .93f), Color(0xFF0D0D28))
        drawRect(Brush.verticalGradient(listOf(Color.Transparent, Color(0xAA0A0820)), startY = h * .75f, endY = h))
    }
}
