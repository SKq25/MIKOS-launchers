package com.mikos.launcher

import android.content.Context
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL

@Composable fun AppHost(name: String, close: () -> Unit) {
    val title = when (name) { "AI" -> "MIKOS AI"; "Speed" -> "5G Network"; else -> name }
    Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF0D1240), Color(0xFF070916)))).statusBarsPadding().navigationBarsPadding().padding(top = 44.dp)) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("‹", fontSize = 36.sp, color = Color.White, modifier = Modifier.clickable { close() }.padding(end = 16.dp))
            Text(title, fontSize = 22.sp, fontWeight = FontWeight.SemiBold, color = Color.White)
        }
        Box(Modifier.weight(1f).padding(horizontal = 14.dp)) {
            when (name) {
                "AI" -> AiChat(); "Speed" -> SpeedTest(); "Weather" -> WeatherApp(); "Notes" -> NotesApp(); "Calculator" -> CalcApp()
            }
        }
    }
}

@Composable fun AiChat() {
    val msgs = remember { mutableStateListOf("ai|Namaste Vinod! Main MIKOS AI hu. Kya madad karu?") }
    var inp by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope(); val ls = rememberLazyListState()
    fun send(t: String) { if (t.isBlank()) return; msgs.add("me|$t"); scope.launch { delay(550); msgs.add("ai|" + aiReply(t)) } }
    LaunchedEffect(msgs.size) { ls.animateScrollToItem(msgs.size - 1) }
    Column(Modifier.fillMaxSize()) {
        LazyColumn(Modifier.weight(1f), state = ls, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(msgs) { m ->
                val me = m.startsWith("me|")
                Box(Modifier.fillMaxWidth(), contentAlignment = if (me) Alignment.CenterEnd else Alignment.CenterStart) {
                    Text(m.substring(3), color = Color.White, modifier = Modifier.widthIn(max = 280.dp).clip(RoundedCornerShape(18.dp)).background(if (me) Color(0xFF3B6BFF) else Color(0xFF1C2670)).padding(12.dp))
                }
            }
        }
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("Plan my day", "Weather kaisa hai?", "Write a message", "Summarize this", "Time kya hua?").forEach {
                Text(it, color = Color.White, fontSize = 12.sp, modifier = Modifier.clip(RoundedCornerShape(14.dp)).background(Color(0xFF151C58)).clickable { send(it) }.padding(horizontal = 12.dp, vertical = 8.dp))
            }
        }
        Row(Modifier.padding(bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(inp, { inp = it }, Modifier.weight(1f), singleLine = true, placeholder = { Text("Message likho…") }, shape = RoundedCornerShape(26.dp))
            Spacer(Modifier.width(8.dp))
            Button(onClick = { send(inp); inp = "" }) { Text("➤") }
        }
    }
}

@Composable fun Gauge(v: Float, max: Float, label: String, unit: String, color: Color, modifier: Modifier = Modifier) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(150.dp, 95.dp), contentAlignment = Alignment.BottomCenter) {
            Canvas(Modifier.fillMaxSize()) {
                val side = size.width - 28f
                val tl = Offset(14f, 14f)
                drawArc(Color(0x22FFFFFF), 180f, 180f, false, tl, Size(side, side), style = Stroke(20f, cap = StrokeCap.Round))
                drawArc(color, 180f, 180f * (v / max).coerceIn(0f, 1f), false, tl, Size(side, side), style = Stroke(20f, cap = StrokeCap.Round))
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("%.0f".format(v), color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                Text(unit, color = Color(0xCCFFFFFF), fontSize = 10.sp)
            }
        }
        Text(label, color = Color.White, fontSize = 13.sp)
    }
}

private fun open(u: String, post: Boolean = false, len: Int = 0): HttpURLConnection {
    val c = URL(u).openConnection() as HttpURLConnection
    c.connectTimeout = 5000; c.readTimeout = 9000
    if (post) { c.requestMethod = "POST"; c.doOutput = true; c.setFixedLengthStreamingMode(len) }
    return c
}

@Composable fun SpeedTest() {
    var dl by remember { mutableFloatStateOf(0f) }; var ul by remember { mutableFloatStateOf(0f) }
    var ping by remember { mutableIntStateOf(0) }; var status by remember { mutableStateOf("Start dabao") }
    var run by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Row(Modifier.fillMaxWidth().glass().padding(14.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
            Gauge(dl, 1000f, "Download", "Mbps", Color(0xFF4DC3FF)); Gauge(ul, 500f, "Upload", "Mbps", Color(0xFFD45BFF))
        }
        Row(Modifier.fillMaxWidth().glass().padding(16.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
            Text("Ping: ${if (ping > 0) "$ping ms" else "--"}", color = Color.White); Text(status, color = Color.White)
        }
        Button(enabled = !run, onClick = {
            run = true; dl = 0f; ul = 0f; ping = 0
            scope.launch(Dispatchers.IO) {
                try {
                    status = "Ping…"
                    val t = ArrayList<Long>()
                    repeat(4) { val s = System.nanoTime(); try { val c = open("https://speed.cloudflare.com/cdn-cgi/trace"); c.inputStream.readBytes(); c.disconnect(); t.add((System.nanoTime() - s) / 1_000_000) } catch (_: Exception) {} }
                    ping = t.minOrNull()?.toInt() ?: 0
                    status = "Download…"
                    val c = open("https://speed.cloudflare.com/__down?bytes=25000000")
                    val st = System.nanoTime(); var n = 0L; val b = ByteArray(65536)
                    c.inputStream.use { ins -> while (true) { val r = ins.read(b); if (r < 0) break; n += r; val s = (System.nanoTime() - st) / 1e9; if (s > .3) dl = (n * 8 / 1e6 / s).toFloat(); if (s > 8) break } }
                    status = "Upload…"
                    val size = 8_000_000; val u = open("https://speed.cloudflare.com/__up", true, size)
                    val st2 = System.nanoTime(); var m = 0; val z = ByteArray(65536)
                    u.outputStream.use { o -> while (m < size) { val k = minOf(z.size, size - m); o.write(z, 0, k); m += k; val s = (System.nanoTime() - st2) / 1e9; if (s > .3) ul = (m * 8 / 1e6 / s).toFloat() } }
                    u.inputStream.readBytes()
                    status = "Complete ✅"
                } catch (e: Exception) { status = "Network error ❌" }
                run = false
            }
        }) { Text(if (run) "Chal raha hai…" else "⚡ 5G Speed Test") }
        Text("Cloudflare speed servers use hote hain. Internet zaroori hai.", color = Color(0x99FFFFFF), fontSize = 11.sp)
    }
}

@Composable fun WeatherApp() {
    val w = Store.weather; val scope = rememberCoroutineScope()
    Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(CITY, color = Color.White, fontSize = 22.sp)
        Text("${w?.temp ?: "--"}°", color = Color.White, fontSize = 80.sp, fontWeight = FontWeight.ExtraLight)
        Text("${w?.let { wxIcon(it.code) + " " + wxText(it.code) } ?: "Load ho raha hai…"}", color = Color.White, fontSize = 18.sp)
        Spacer(Modifier.height(20.dp))
        (w?.days ?: emptyList()).forEach {
            Row(Modifier.fillMaxWidth().padding(vertical = 5.dp).glass(18.dp).padding(14.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(it.name, color = Color.White); Text(wxIcon(it.code), fontSize = 20.sp); Text("${it.hi}° / ${it.lo}°", color = Color.White)
            }
        }
        Spacer(Modifier.height(14.dp))
        Button(onClick = { scope.launch { fetchWeather() } }) { Text("🔄 Refresh") }
    }
}

@Composable fun NotesApp() {
    val ctx = LocalContext.current; val sp = remember { ctx.getSharedPreferences("mikos", Context.MODE_PRIVATE) }
    val notes = remember { mutableStateListOf<String>().apply { val a = JSONArray(sp.getString("notes", "[]")); for (i in 0 until a.length()) add(a.getString(i)) } }
    fun save() { sp.edit().putString("notes", JSONArray(notes).toString()).apply() }
    var ed by remember { mutableIntStateOf(-2) }; var txt by remember { mutableStateOf("") }
    BackHandler(ed != -2) { ed = -2 }
    if (ed == -2) {
        Box(Modifier.fillMaxSize()) {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                itemsIndexed(notes) { i, n -> Text(n.lines().first().ifBlank { "Khali note" }, color = Color.White, modifier = Modifier.fillMaxWidth().glass(18.dp).clickable { txt = n; ed = i }.padding(16.dp)) }
            }
            if (notes.isEmpty()) Text("Koi note nahi. + dabao.", color = Color(0x99FFFFFF), modifier = Modifier.align(Alignment.Center))
            Button(onClick = { txt = ""; ed = -1 }, modifier = Modifier.align(Alignment.BottomEnd).padding(bottom = 12.dp)) { Text("+ Naya") }
        }
    } else {
        Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedTextField(txt, { txt = it }, Modifier.fillMaxWidth().weight(1f), placeholder = { Text("Yaha likho…") })
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(onClick = { if (txt.isNotBlank()) { if (ed == -1) notes.add(0, txt) else notes[ed] = txt } else if (ed >= 0) notes.removeAt(ed); save(); ed = -2 }) { Text("Save") }
                if (ed >= 0) Button(onClick = { notes.removeAt(ed); save(); ed = -2 }) { Text("Delete") }
            }
        }
    }
}

@Composable fun CalcApp() {
    var ex by remember { mutableStateOf("") }
    val res = remember(ex) { if (ex.isEmpty()) "" else calc(ex) ?: "" }
    val keys = listOf("C", "⌫", "%", "÷", "7", "8", "9", "×", "4", "5", "6", "−", "1", "2", "3", "+", "00", "0", ".", "=")
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Column(Modifier.fillMaxWidth().height(140.dp), horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.Bottom) {
            Text(ex, color = Color(0xAAFFFFFF), fontSize = 20.sp); Text(res.ifEmpty { ex.ifEmpty { "0" } }, color = Color.White, fontSize = 48.sp, fontWeight = FontWeight.Light)
        }
        keys.chunked(4).forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                row.forEach { k ->
                    Box(
                        Modifier.weight(1f).height(60.dp).clip(RoundedCornerShape(30.dp))
                            .background(if (k in "÷×−+=") Brush.linearGradient(listOf(Color(0xFF6A3CFF), Color(0xFF2F9BFF))) else Brush.linearGradient(listOf(Color(0xFF151C58), Color(0xFF151C58))))
                            .clickable {
                                when (k) {
                                    "C" -> { ex = "" }
                                    "⌫" -> { ex = ex.dropLast(1) }
                                    "=" -> { if (res.isNotEmpty()) ex = res }
                                    else -> { ex += k }
                                }
                            },
                        contentAlignment = Alignment.Center
                    ) { Text(k, color = Color.White, fontSize = 22.sp) }
                }
            }
        }
    }
}
